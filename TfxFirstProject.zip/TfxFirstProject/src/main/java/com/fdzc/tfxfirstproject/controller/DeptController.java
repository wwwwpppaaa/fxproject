package com.fdzc.tfxfirstproject.controller;

import com.fdzc.tfxfirstproject.entity.Dept;
import com.fdzc.tfxfirstproject.entity.User;
import com.fdzc.tfxfirstproject.service.DeptService;
import com.fdzc.tfxfirstproject.service.UserService;
import com.fdzc.tfxfirstproject.vo.DeptVo;
import com.fdzc.tfxfirstproject.vo.UserVo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;
@RestController
public class DeptController {
    @Autowired
    // private UserService userService;
    private DeptService deptService;

    //insert
    @PostMapping("/insertDept")
    public String insertDept(@RequestBody Dept dept)
    {
        System.out.println(dept);
        if(deptService.insertDept(dept) == 1)
        {
            return "添加成功";
        }
        return "添加失败";
    }

    @PostMapping("/batchInsertDept")
    public String batchInsertDept(@RequestBody List<Dept> dept)
    {
        for (Dept dept1 : dept){
            deptService.insertDept(dept1);
        }
        return "添加成功";
    }
    //delete
    @DeleteMapping("/delterDept")
    public String delterDept(@RequestParam("id") Integer id)
    {
        if(deptService.delterDept(id) >= 1)
        {
            return "删除成功";
        }
        return "删除失败";
    }

    // @DeleteMapping("batchDeleteDept")
    // public String batchDeleteDept(@RequestBody List<Integer> ids)
    // {
    //     deptService.batchDeleteDept(ids);
    //     return "删除成功";
    // }
    @PostMapping("batchDeleteDept")
    public String batchDeleteDept(int[] id)
    {
        List<Integer> ids = new ArrayList<>();
        for (int i:
                id) {
            System.out.println(i);
            ids.add(i);
        }
        deptService.batchDeleteDept(ids);

        return "删除成功";
    }
    //update
    @PostMapping("updateDept")
    public String updateUser(@RequestBody Dept dept)
    {
        if(deptService.updateDept(dept) >= 1)
        {
            return "更新成功";
        }
        return "更新失败";
    }

    //查找用户全部信息
    @GetMapping ("/findDeptAll")
    @ResponseBody
    public List<Dept> findDeptAll(){

        return deptService.findDeptAll();
    }

    @GetMapping("findDept")
    public Dept findDept(int id)
    {
        return deptService.findDept(id);
    }

    @GetMapping("findUserDeptList")
    public DeptVo findUserDept(Integer id)
    {
        return deptService.findUserDept(id);

    }
}
