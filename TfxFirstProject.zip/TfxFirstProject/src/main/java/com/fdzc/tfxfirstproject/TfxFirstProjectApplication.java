package com.fdzc.tfxfirstproject;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TfxFirstProjectApplication {

    public static void main(String[] args) {

        SpringApplication.run(TfxFirstProjectApplication.class, args);

    }

}
