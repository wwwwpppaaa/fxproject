package com.fdzc.tfxfirstproject.service;

import com.fdzc.tfxfirstproject.entity.Dept;
import com.fdzc.tfxfirstproject.entity.User;
import com.fdzc.tfxfirstproject.mapper.DeptMapper;
import com.fdzc.tfxfirstproject.mapper.UserMapper;
import com.fdzc.tfxfirstproject.vo.DeptVo;
import com.fdzc.tfxfirstproject.vo.UserVo;
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class DeptService {
    @Autowired
    private DeptMapper deptMapper;

    public int insertDept(Dept dept)
    {
        return deptMapper.insertDept(dept);
    }

    public int batchInsertDept(List<Dept> deptList)
    {

        return deptMapper.batchInsertDept(deptList);
    }

    public int delterDept(Integer id)
    {
        return deptMapper.delete(id);
    }


    public int batchDeleteDept(List<Integer> ids)
    {

        return deptMapper.batchDeleteDept(ids);
    }

    public int updateDept(Dept dept)
    {
        return deptMapper.updateDept(dept);
    }

    public Dept findDept(Integer id){
        return deptMapper.findDept(id);
    }

    public List<Dept> findDeptAll(){
        return deptMapper.findDeptAll();
    }

    public DeptVo findUserDept(Integer id)
    {
        return deptMapper.findUserDept(id);
    }
}
