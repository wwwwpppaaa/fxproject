package com.fdzc.tfxfirstproject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TfxFirstProjectApplicationTests {

    @Test
    void contextLoads() {
    }

}
